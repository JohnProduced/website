<?php
/**
 * Search Template
 *
 * This template is loaded when viewing search results and replaces the default template.
 * 
 * @package Agile
 * @subpackage Template
 */



get_header(); 

mo_display_archive_content(); 

get_sidebar();

get_footer(); 

?>